(() => {
  const cfg = () => window.FINVERSE_SUPPORT || {};
  const $ = id => document.getElementById(id);
  const clean = value => String(value || '').trim();
  const validHttpUrl = value => { try { const u = new URL(value); return u.protocol === 'https:' || u.protocol === 'http:' ? u.href : ''; } catch { return ''; } };
  const setLink = (id, value, href) => { const el = $(id); if (!el) return; const v = clean(value); if (v && href) { el.href = href; el.hidden = false; } else { el.removeAttribute('href'); el.hidden = true; } };
  window.renderFinVerseSupport = function() {
    const c = cfg();
    const email = clean(c.email), phone = clean(c.phone);
    $('supportEmailText').textContent = email || 'Support email not configured yet. Add it in support-config.js.';
    $('supportPhoneText').textContent = phone || 'Phone number not configured yet. Add it in support-config.js.';
    setLink('supportEmailLink', email, email ? 'mailto:' + email : '');
    setLink('supportPhoneLink', phone, phone ? 'tel:' + phone.replace(/[^+\d]/g, '') : '');
    const social = [
      ['Instagram', c.instagram, '◎'], ['Facebook', c.facebook, 'f'],
      ['WhatsApp', c.whatsapp, '◉'], ['LinkedIn', c.linkedin, 'in']
    ];
    const wrap = $('supportSocialLinks'); wrap.replaceChildren();
    let count = 0;
    social.forEach(([name, value, icon]) => {
      const url = validHttpUrl(value); if (!url) return;
      const a = document.createElement('a'); a.className = 'support-social-link'; a.href = url;
      a.target = '_blank'; a.rel = 'noopener noreferrer'; a.textContent = icon + ' ' + name; wrap.appendChild(a); count++;
    });
    if (!count) { const msg = document.createElement('span'); msg.textContent = 'Set your official Instagram, Facebook, WhatsApp, and LinkedIn URLs in support-config.js.'; wrap.appendChild(msg); }
    const status = $('supportFormStatus');
    if (status) status.textContent = email ? 'Your email app will open with your request prepared. Review it before sending.' : 'Add your official support email in support-config.js before using this form.';
  };
  const form = $('supportForm');
  if (form) form.addEventListener('submit', event => {
    event.preventDefault();
    const email = clean(cfg().email), status = $('supportFormStatus');
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      status.textContent = 'Support email is not configured. Add your real email in support-config.js first.'; return;
    }
    const name = clean($('supportName').value), reply = clean($('supportReplyEmail').value);
    const topic = clean($('supportTopic').value), message = clean($('supportMessage').value);
    if (!name || !reply || !message) { status.textContent = 'Please complete all required fields.'; return; }
    const subject = '[FinVerse AI Support] ' + topic;
    const body = `Name: ${name}\nReply email: ${reply}\nTopic: ${topic}\n\nMessage:\n${message}\n\nSent from the FinVerse AI support page.`;
    const url = 'mailto:' + encodeURIComponent(email) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
    status.textContent = 'Opening your email application. Check the draft and press Send to contact support.';
    window.location.href = url;
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', window.renderFinVerseSupport); else window.renderFinVerseSupport();
})();
