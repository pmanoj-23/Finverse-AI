import express from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '24kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(__dirname));

const apiKey = process.env.GEMINI_API_KEY?.trim();
const client = apiKey ? new GoogleGenAI({ apiKey }) : null;
const instructions = `You are FinVerse AI, a practical, beginner-friendly financial education assistant for users in India. Understand the user's context, ask concise follow-up questions when key information is missing, explain trade-offs, and offer actionable next steps. Help with budgeting, savings, emergency funds, debt basics, investment education, SIP concepts, portfolio risk, trading concepts, Indian tax concepts, scam awareness, invoices, and small-business cash flow. Use INR and Indian context when appropriate. Do not pretend to know current market prices, current tax law, a user's bank balances, or external facts unless supplied or verified. Clearly label assumptions and estimates. Never guarantee returns, give pressure-based buy/sell calls, or claim to be a SEBI-registered adviser, CA, lawyer, or bank. For personalized investment decisions, discuss risk, time horizon, diversification, and emergency savings; recommend a qualified SEBI-registered adviser when appropriate. For tax/legal questions, explain general concepts and tell the user to verify current official rules or consult a qualified professional. For fraud concerns, recommend not clicking links or sharing OTPs, UPI PINs, passwords, or remote-access permissions, and verify through official channels. Never request secrets. Keep answers clear, supportive, structured, and actionable. Do not invent product features or claim FinVerse has connected to a bank or live data source.`;

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, provider: 'gemini', configured: Boolean(client) });
});

// Market-data provider adapter. Twelve Data is used for NSE-listed equities when configured;
// NIFTY/SENSEX indices and any fallback requests use Yahoo's unofficial chart endpoint.
// A connected provider is not proof of an exchange-licensed real-time feed.
const TWELVE_DATA_API_KEY = process.env.TWELVE_DATA_API_KEY?.trim();
const MARKET_SYMBOLS = {
  NIFTY: '^NSEI', SENSEX: '^BSESN', RELIANCE: 'RELIANCE.NS', TCS: 'TCS.NS',
  INFY: 'INFY.NS', HDFCBANK: 'HDFCBANK.NS', ICICIBANK: 'ICICIBANK.NS',
  SBIN: 'SBIN.NS', TATAMOTORS: 'TMPV.NS'
};
const TWELVE_SYMBOLS = {
  RELIANCE: 'RELIANCE', TCS: 'TCS', INFY: 'INFY', HDFCBANK: 'HDFCBANK',
  ICICIBANK: 'ICICIBANK', SBIN: 'SBIN', TATAMOTORS: 'TMPV'
};
const marketCache = new Map();
const MARKET_CACHE_MS = 30_000;
function marketResponse(payload, flags = {}) {
  const updatedMs = Date.parse(payload.updatedAt);
  const quoteAgeSeconds = Number.isFinite(updatedMs) ? Math.max(0, Math.floor((Date.now() - updatedMs) / 1000)) : null;
  return { ...payload, quoteAgeSeconds, quoteFresh: quoteAgeSeconds !== null && quoteAgeSeconds <= 5 * 60, ...flags };
}
function marketStateIndia() {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date());
  const get = type => parts.find(part => part.type === type)?.value;
  const day = get('weekday'), minuteOfDay = Number(get('hour')) * 60 + Number(get('minute'));
  if (day === 'Sat' || day === 'Sun') return 'CLOSED';
  if (minuteOfDay < 9 * 60 + 15) return 'PRE';
  if (minuteOfDay > 15 * 60 + 30) return 'POST';
  return 'REGULAR';
}
function parseProviderTime(value) {
  if (value == null) return null;
  if (typeof value === 'number' || /^\d{10,13}$/.test(String(value))) {
    const n = Number(value); return new Date(n < 1e12 ? n * 1000 : n).toISOString();
  }
  const text = String(value).trim();
  // Twelve Data timestamps without an offset are exchange-local; NSE timestamps are IST.
  const normalized = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(text) ? text : `${text.replace(' ', 'T')}+05:30`;
  const ms = Date.parse(normalized);
  return Number.isFinite(ms) ? new Date(ms).toISOString() : null;
}
async function fetchTwelveData(requested) {
  const symbol = TWELVE_SYMBOLS[requested];
  if (!TWELVE_DATA_API_KEY || !symbol) throw new Error('Twelve Data is not configured for this symbol');
  const base = 'https://api.twelvedata.com';
  const params = new URLSearchParams({ symbol, exchange: 'NSE', apikey: TWELVE_DATA_API_KEY });
  const quoteResp = await fetch(`${base}/quote?${params}`, { signal: AbortSignal.timeout(8000), headers: { Accept: 'application/json' } });
  if (!quoteResp.ok) throw new Error(`Twelve Data quote HTTP ${quoteResp.status}`);
  const quote = await quoteResp.json();
  if (quote.status === 'error' || quote.code || quote.close == null) throw new Error(quote.message || 'Twelve Data returned no quote');
  const historyParams = new URLSearchParams({ symbol, exchange: 'NSE', interval: '5min', outputsize: '120', apikey: TWELVE_DATA_API_KEY });
  const histResp = await fetch(`${base}/time_series?${historyParams}`, { signal: AbortSignal.timeout(8000), headers: { Accept: 'application/json' } });
  if (!histResp.ok) throw new Error(`Twelve Data history HTTP ${histResp.status}`);
  const hist = await histResp.json();
  if (hist.status === 'error' || !Array.isArray(hist.values) || !hist.values.length) throw new Error(hist.message || 'Twelve Data returned no history');
  const history = hist.values.slice().reverse().map(point => ({
    date: parseProviderTime(point.datetime), close: Number(point.close), volume: point.volume == null ? null : Number(point.volume)
  })).filter(point => point.date && Number.isFinite(point.close));
  const price = Number(quote.close), previousCloseRaw = Number(quote.previous_close);
  if (!Number.isFinite(price)) throw new Error('Twelve Data quote price was invalid');
  const previousClose = Number.isFinite(previousCloseRaw) ? previousCloseRaw : price;
  const updatedAt = parseProviderTime(quote.timestamp || quote.datetime) || history.at(-1)?.date || new Date().toISOString();
  return {
    requestedSymbol: requested, providerSymbol: `${symbol}:NSE`, name: quote.name || requested,
    currency: quote.currency || 'INR', exchange: quote.exchange || 'NSE', price,
    previousClose: Number.isFinite(previousClose) ? previousClose : price,
    change: Number.isFinite(Number(quote.change)) ? Number(quote.change) : price - previousClose,
    changePercent: Number.isFinite(Number(quote.percent_change)) ? Number(quote.percent_change) : (previousClose ? ((price - previousClose) / previousClose) * 100 : 0),
    marketState: marketStateIndia(), updatedAt, history, interval: '5min', source: 'Twelve Data API (NSE equity quote; plan and exchange entitlements determine latency)',
    provider: 'twelvedata', disclaimer: 'Quote supplied by Twelve Data. Real-time availability depends on the account plan and exchange licensing; verify timestamp and market status before relying on it.'
  };
}
async function fetchYahoo(requested) {
  const symbol = MARKET_SYMBOLS[requested];
  const plans = [{ range: '1d', interval: '1m' }, { range: '5d', interval: '5m' }, { range: '3mo', interval: '1d' }];
  let result = null, lastError = null, usedPlan = null;
  for (const plan of plans) {
    for (const host of ['query1.finance.yahoo.com', 'query2.finance.yahoo.com']) {
      try {
        const url = `https://${host}/v8/finance/chart/${encodeURIComponent(symbol)}?range=${plan.range}&interval=${plan.interval}&events=history`;
        const upstream = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36', Accept: 'application/json' }, signal: AbortSignal.timeout(6500) });
        if (!upstream.ok) throw new Error(`Yahoo Finance HTTP ${upstream.status}`);
        const body = await upstream.json();
        const candidate = body?.chart?.result?.[0];
        if (!candidate) throw new Error(body?.chart?.error?.description || 'Yahoo Finance returned no chart data');
        const timestamps = candidate.timestamp || [], quote = candidate.indicators?.quote?.[0] || {}, closes = quote.close || [], volumes = quote.volume || [];
        const history = timestamps.map((ts, i) => ({ date: new Date(ts * 1000).toISOString(), close: closes[i] == null ? null : Number(closes[i]), volume: volumes[i] == null ? null : Number(volumes[i]) })).filter(point => Number.isFinite(point.close));
        if (!history.length) throw new Error('Yahoo Finance returned no usable price points');
        result = { meta: candidate.meta || {}, history }; usedPlan = plan; break;
      } catch (error) { lastError = error; }
    }
    if (result) break;
  }
  if (!result) throw lastError || new Error('Yahoo Finance unavailable');
  const { meta, history } = result, latestHistory = history.at(-1);
  const price = Number.isFinite(meta.regularMarketPrice) ? meta.regularMarketPrice : latestHistory.close;
  const previousClose = Number.isFinite(meta.chartPreviousClose) ? meta.chartPreviousClose : (Number.isFinite(meta.previousClose) ? meta.previousClose : price);
  return {
    requestedSymbol: requested, providerSymbol: symbol, name: meta.longName || meta.shortName || requested,
    currency: meta.currency || 'INR', exchange: meta.fullExchangeName || meta.exchangeName || 'Market', price, previousClose,
    change: price - previousClose, changePercent: previousClose ? ((price - previousClose) / previousClose) * 100 : 0,
    marketState: meta.marketState || marketStateIndia(), updatedAt: meta.regularMarketTime ? new Date(meta.regularMarketTime * 1000).toISOString() : latestHistory.date,
    history, interval: usedPlan.interval, source: 'Yahoo Finance chart endpoint (unofficial; may be delayed or unavailable)', provider: 'yahoo',
    disclaimer: 'Prototype quote only; Yahoo Finance is not an exchange-licensed real-time feed for this app. Quotes may be delayed, stale, or unavailable. Verify with your broker or exchange.'
  };
}
app.get('/api/market/providers', (_req, res) => res.json({
  primary: TWELVE_DATA_API_KEY ? 'twelvedata' : 'yahoo',
  twelveDataConfigured: Boolean(TWELVE_DATA_API_KEY),
  note: TWELVE_DATA_API_KEY ? 'Twelve Data is used for supported NSE equities; indices and failures fall back to Yahoo Finance.' : 'Add TWELVE_DATA_API_KEY to .env to use Twelve Data for supported NSE equities. Yahoo Finance remains an unofficial fallback.'
}));
app.get('/api/market', async (req, res) => {
  const requested = String(req.query.symbol || 'NIFTY').toUpperCase();
  if (!MARKET_SYMBOLS[requested]) return res.status(400).json({ error: 'Unsupported symbol. Choose one of the listed market instruments.' });
  const cached = marketCache.get(requested);
  if (cached && Date.now() - cached.savedAt < MARKET_CACHE_MS) return res.json(marketResponse(cached.payload, { cached: true }));
  let payload = null, twelveError = null, yahooError = null;
  if (TWELVE_DATA_API_KEY && TWELVE_SYMBOLS[requested]) {
    try { payload = await fetchTwelveData(requested); }
    catch (error) { twelveError = error; console.warn('Twelve Data request failed:', error.message); }
  }
  // Yahoo is currently the fallback for indices and provider failures; its source is explicitly labelled.
  if (!payload) {
    try {
      payload = await fetchYahoo(requested);
      if (twelveError) payload.fallbackWarning = 'Twelve Data failed; serving the Yahoo Finance fallback. ' + String(twelveError.message).slice(0, 140);
    } catch (error) { yahooError = error; }
  }
  if (!payload) {
    if (cached) return res.json(marketResponse(cached.payload, { cached: true, stale: true, warning: 'All market providers are temporarily unavailable; showing the last successful quote.' }));
    const detail = [twelveError?.message, yahooError?.message].filter(Boolean).join('; ') || 'No provider configured';
    console.error('Market data request failed:', detail);
    return res.status(502).json({ error: 'Market data providers are temporarily unavailable. No fabricated price is shown.', detail: detail.slice(0, 250), providers: { twelveDataConfigured: Boolean(TWELVE_DATA_API_KEY), yahooFallback: true } });
  }
  marketCache.set(requested, { savedAt: Date.now(), payload });
  res.json(marketResponse(payload, { cached: false, providerFallback: Boolean(twelveError && payload.provider === 'yahoo') }));
});

app.post('/api/chat', async (req, res) => {
  if (!client) return res.status(503).json({ error: 'Gemini is not configured. Add GEMINI_API_KEY to the .env file and restart the server.' });
  const messages = req.body?.messages;
  const allowedLanguages = ['English', 'Hindi', 'Telugu', 'Tamil', 'Bengali', 'Kannada', 'Malayalam', 'Marathi'];
  const requestedLanguage = allowedLanguages.includes(req.body?.language) ? req.body.language : 'English';
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 12) return res.status(400).json({ error: 'Send between 1 and 12 recent messages.' });
  const clean = [];
  for (const m of messages) {
    // Only new user input is limited to 2,000 characters. Assistant answers can be longer;
    // trim old history so a previous answer cannot break the next turn.
    if (!m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || !m.content.trim()) continue;
    const content = m.role === 'user' ? m.content.trim() : m.content.trim().slice(0, 1400);
    if (m.role === 'user' && content.length > 2000) return res.status(400).json({ error: 'Please keep each question under 2,000 characters.' });
    const role = m.role === 'assistant' ? 'model' : 'user';
    // Gemini expects alternating user/model turns. Merge consecutive messages with the same role.
    if (clean.length && clean[clean.length - 1].role === role) {
      const prior = clean[clean.length - 1].parts[0].text;
      clean[clean.length - 1].parts[0].text = (prior + '\n' + content).slice(-2000);
    } else clean.push({ role, parts: [{ text: content.slice(-2000) }] });
  }
  while (clean.length && clean[0].role !== 'user') clean.shift();
  if (!clean.length) return res.status(400).json({ error: 'Please send a question to start the conversation.' });
  if (clean.length > 12) clean.splice(0, clean.length - 12);
  while (clean.length && clean[0].role !== 'user') clean.shift();
  try {
    const liveQuotes = [...marketCache.values()]
      .filter(item => Date.now() - item.savedAt < 15 * 60_000)
      .map(item => item.payload)
      .slice(0, 8)
      .map(q => `${q.name} (${q.requestedSymbol}): ${q.currency} ${Number(q.price).toLocaleString('en-IN')} ; change ${Number(q.changePercent).toFixed(2)}% vs previous close; quote timestamp ${q.updatedAt}; source ${q.source}.`);
    const marketContext = liveQuotes.length
      ? `\n\nMarket data available from the server cache (may be delayed; always mention timestamp and source, never imply exchange-real-time):\n${liveQuotes.join('\n')}`
      : '\n\nNo current market quotes are available in the server cache. Do not invent current prices; explain that the user should refresh Trading AI.';
    const response = await client.models.generateContent({
      model: process.env.GEMINI_MODEL?.trim() || 'gemini-flash-latest',
      contents: clean,
      config: { systemInstruction: instructions + `\n\nLANGUAGE REQUIREMENT: Reply entirely in ${requestedLanguage}. Keep financial terms understandable for a beginner; when useful, include a familiar English term in parentheses. Do not switch languages unless the user asks. Format answers with clear short headings and bullet lists. Finish every answer with a complete sentence; never stop mid-sentence or leave a heading/list unfinished. Prefer concise, complete answers over long answers.`, maxOutputTokens: 3072 }
    });
    const answer = response.text?.trim();
    if (!answer) return res.status(502).json({ error: 'Gemini returned an empty response. Please try again.' });
    res.json({ answer });
  } catch (err) {
    const status = err?.status || err?.code || 'unknown';
    console.error('Gemini request failed:', status, err?.message || 'No error details');
    if (Number(status) === 400) return res.status(502).json({ error: 'Gemini rejected the request. Check the configured model and request settings.' });
    if (Number(status) === 401 || Number(status) === 403) return res.status(502).json({ error: 'Gemini API authentication or permission failed. Check that your Gemini API key is valid and enabled for the Gemini API.' });
    if (Number(status) === 429) return res.status(502).json({ error: 'Gemini rate limit or quota reached. Check your Google AI Studio usage and rate limits, then wait or use an available model.' });
    res.status(502).json({ error: 'Could not get a response from Gemini. Check the CMD server log, API key, model access, and network connection.' });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`FinVerse AI running at http://localhost:${port} (Gemini provider)`));
