/* FinVerse AI support contacts. Replace the empty strings with your real, official contact details. */
window.FINVERSE_SUPPORT = {
  email: "",       // Example: support@yourdomain.com
  phone: "",       // Example: +91 98765 43210
  instagram: "",   // Full profile URL, e.g. https://www.instagram.com/yourhandle/
  facebook: "",    // Full page URL, e.g. https://www.facebook.com/yourpage
  whatsapp: "",    // Full wa.me URL, e.g. https://wa.me/919876543210
  linkedin: ""     // Full company page URL
};
