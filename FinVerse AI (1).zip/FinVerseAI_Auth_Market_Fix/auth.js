// FinVerse AI local demo authentication. No Firebase or remote auth provider is used.
// IMPORTANT: This client-side demo is not secure authentication and must not protect real financial data.
const $ = id => document.getElementById(id);
const gate = $('authGate');
let mode = 'login';
const ADMIN_EMAIL = 'admin@finverse.ai';
const ADMIN_PASSWORD = 'FinVerse@123';
const USERS_KEY = 'finverse.demoUsers.v1';
const SESSION_KEY = 'finverse.demoSession.v1';

function readUsers(){ try { const x=JSON.parse(localStorage.getItem(USERS_KEY)||'{}'); return x && typeof x==='object' ? x : {}; } catch { return {}; } }
function showMessage(text, ok=false){ $('authError').textContent=text; $('authError').style.color=ok?'#5ee0bd':'#ff9cc2'; }
function setMode(next){
  mode=next;
  $('showLogin').classList.toggle('active',mode==='login');
  $('showSignup').classList.toggle('active',mode==='signup');
  $('authName').hidden=mode!=='signup'; $('authNameLabel').hidden=mode!=='signup'; $('authName').required=mode==='signup';
  $('authTitle').textContent=mode==='login'?'Welcome to FinVerse AI':'Create your demo account';
  $('authIntro').textContent=mode==='login'?'Use the admin demo credentials below or sign in with a locally created demo account.':'Create a demo account saved only in this browser.';
  $('authSubmit').textContent=mode==='login'?'Login':'Create demo account';
  $('forgotPassword').hidden=true;
  $('authPassword').autocomplete=mode==='login'?'current-password':'new-password';
  $('authEmail').readOnly=false; $('authPassword').readOnly=false;
  showMessage('');
}
function enterWorkspace(email, label=''){ localStorage.setItem(SESSION_KEY,JSON.stringify({email,role:label||'demo',signedInAt:Date.now()})); $('accountEmail').textContent=email+(label==='admin'?' · Admin':' · Demo'); gate.classList.add('hidden'); document.body.classList.remove('auth-locked'); }
function leaveWorkspace(){ localStorage.removeItem(SESSION_KEY); location.reload(); }
$('adminDemoLogin')?.addEventListener('click',()=>{
  setMode('login');
  $('authEmail').value=ADMIN_EMAIL;
  $('authPassword').value=ADMIN_PASSWORD;
  $('authForm').requestSubmit();
});
$('showLogin').addEventListener('click',()=>setMode('login'));
$('showSignup').addEventListener('click',()=>setMode('signup'));
$('forgotPassword').hidden=true;
$('authForm').addEventListener('submit',async event=>{
  event.preventDefault(); showMessage('');
  const email=$('authEmail').value.trim().toLowerCase(), password=$('authPassword').value;
  if(!email || !/^\S+@\S+\.\S+$/.test(email)) return showMessage('Enter a valid email address.');
  if(mode==='signup'){
    const name=$('authName').value.trim();
    if(!name) return showMessage('Enter your full name.');
    if(password.length<8) return showMessage('Use at least 8 characters for a demo password.');
    if(email===ADMIN_EMAIL) return showMessage('That email is reserved for the displayed admin demo account.');
    const users=readUsers();
    if(users[email]) return showMessage('A demo account already exists for this email. Switch to Login.');
    // Hash local demo passwords with PBKDF2. This is still browser-only demo auth, not production auth.
    try {
      const salt=crypto.getRandomValues(new Uint8Array(16));
      const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
      const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:120000,hash:'SHA-256'},material,256);
      users[email]={name,salt:Array.from(salt),hash:Array.from(new Uint8Array(bits)),createdAt:new Date().toISOString()};
      localStorage.setItem(USERS_KEY,JSON.stringify(users));
      setMode('login'); $('authEmail').value=email; $('authPassword').value='';
      showMessage('Demo account created in this browser. Log in with the email and password you chose.',true);
    } catch(err){ showMessage('Could not create a local demo account: '+(err.message||'browser crypto unavailable')); }
    return;
  }
  if(email===ADMIN_EMAIL && password===ADMIN_PASSWORD){ enterWorkspace(email,'admin'); return; }
  const record=readUsers()[email];
  if(!record) return showMessage('No local demo account found for this email. Create a demo account first.');
  try {
    const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
    const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new Uint8Array(record.salt),iterations:120000,hash:'SHA-256'},material,256);
    const actual=Array.from(new Uint8Array(bits));
    if(actual.length!==record.hash.length || actual.some((v,i)=>v!==record.hash[i])) return showMessage('Email or password is incorrect.');
    enterWorkspace(email,'demo');
  } catch(err){ showMessage('Could not verify the local demo account: '+(err.message||'unknown error')); }
});
$('accountLogout').addEventListener('click',leaveWorkspace);
const existing=(()=>{try{return JSON.parse(localStorage.getItem(SESSION_KEY)||'null')}catch{return null}})();
if(existing?.email){ $('accountEmail').textContent=existing.email+(existing.role==='admin'?' · Admin':' · Demo'); gate.classList.add('hidden'); document.body.classList.remove('auth-locked'); }
else { gate.classList.remove('hidden'); document.body.classList.add('auth-locked'); }
// Show credentials intentionally for hackathon demonstration. Never use these on a public deployment.
