FINVERSE AI — LOCAL HACKATHON DEMO
==================================

REQUIREMENTS
- Node.js 20 or newer recommended
- Internet connection for the external market-data provider and optional Gemini assistant

START
1. Extract this ZIP into a new folder.
2. Open Command Prompt in that folder.
3. Run: npm install
4. Optional: copy .env.example to .env and add your own GEMINI_API_KEY. Never share or commit the .env file.
5. Run: npm start
6. Open http://localhost:3000

DEMO ADMIN LOGIN (VISIBLE ON LOGIN SCREEN)
Email: admin@finverse.ai
Password: FinVerse@123

DEMO SIGNUP
- Use Create account to create another local demo account.
- Local accounts and financial demo records are stored only in this browser. They do not sync between browsers or devices.
- The demo admin credential is intentionally hardcoded and displayed for hackathon demonstration. Anyone with access to the source or login page can see it. This is NOT secure authentication. Do not deploy this version publicly or use real financial data.
- Firebase has been removed from this project. There is no cloud identity, email verification, password reset, or server-side per-user authorization.

MARKET DATA
- GET /api/market?symbol=NIFTY returns a quote and chart history. GET /api/market/providers shows which providers are configured.
- Optional separate provider: create a Twelve Data account, obtain an API key, copy .env.example to .env, and set TWELVE_DATA_API_KEY to your key. The key stays on the Node server and is never sent to the browser. Twelve Data is used for supported NSE-listed equities (Reliance, TCS, Infosys, HDFC Bank, ICICI Bank, SBI and Tata Motors). Check your plan for NSE coverage, request limits and quote delay.
- NIFTY 50 and SENSEX currently use the Yahoo Finance chart endpoint because Twelve Data index availability is not guaranteed. Yahoo is unofficial and may be delayed or blocked. If Twelve Data fails, equities fall back to Yahoo and the API response labels the provider and fallback warning.
- Market quotes cache for 30 seconds. The UI refreshes about every minute while visible. No API can make prices truly real-time unless the plan explicitly includes real-time NSE/BSE rights. Check quote timestamps and provider source; do not treat “provider connected” as proof of live data.
- Quotes may be delayed, stale, or unavailable. Verify important prices with your broker or exchange. GET /api/health checks the Node server and whether Gemini is configured.

AI ASSISTANT
- Gemini-powered chat requires GEMINI_API_KEY in .env. Without it, the rest of the app still runs but the AI chat endpoint reports that setup is needed.
- No bank account connection is implemented. Calculators and fraud detection are prototype features, not professional advice or guarantees.

DATA AND SECURITY LIMITATIONS
- Demo accounts and local invoices/cash-flow records use browser local storage. They are not encrypted and are not suitable for real financial or personal data.
- Do not commit .env or publish this demo admin credential. Replace demo authentication with server-side authentication, authorization, secure storage, and a proper market-data provider before public deployment.


HELP & SUPPORT CONTACT DETAILS
------------------------------
The app now includes a Help & Support page with an email contact form and optional phone, Instagram, Facebook, WhatsApp, and LinkedIn links. To publish your actual contact details, edit support-config.js and replace the empty strings with official contact details/URLs. The support form opens the visitor's email application; it does not send/store messages on the server. Do not put fake contact details here, and do not ask customers to share passwords, OTPs, API keys, or bank account information.
